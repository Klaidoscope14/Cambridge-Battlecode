"""Debug: indicators, profiling, trace."""
